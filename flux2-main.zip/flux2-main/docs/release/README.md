# Flux Dev Documentation

## Release specifications

- [Flux distribution](https://fluxcd.io/flux/releases/)
- [Flux APIs and controllers](https://fluxcd.io/flux/releases/controllers/)
- [Flux shared packages](https://fluxcd.io/flux/releases/packages/)
- [Flux release procedures](https://fluxcd.io/flux/releases/procedure/)
- [Flux release notes template](release-notes-template.md)
